# Google Play Store App Analysis

This project analyzes and visualizes Google Play Store app data.

## Features
- Top 5 app categories by count
- Top 5 categories by average rating
- Free vs Paid app distribution pie chart
- Scatter plot of reviews vs ratings
- Top 5 most expensive paid apps

## How to Run
1. Ensure the file `googleplaystore.csv` is in the same directory as `scraper.py`
2. Run the script using Python: `python scraper.py`

## Requirements
- pandas
- matplotlib
- seaborn