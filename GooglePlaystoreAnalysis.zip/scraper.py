import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load Dataset
df = pd.read_csv("googleplaystore.csv")
df = df[df['Rating'] <= 5]  # Remove invalid ratings
df.dropna(inplace=True)
df['Installs'] = df['Installs'].str.replace('+','', regex=False).str.replace(',','').astype(int)
df['Price'] = df['Price'].str.replace('$','').astype(float)
df['Reviews'] = df['Reviews'].astype(int)

# 1. Top 5 App Categories
top_categories = df['Category'].value_counts().head(5)
top_categories.plot(kind='bar', title='Top 5 App Categories', color='lightblue')
plt.xlabel('Category'); plt.ylabel('Number of Apps'); plt.show()

# 2. Average Rating by Category
df.groupby('Category')['Rating'].mean().sort_values(ascending=False).head(5).plot(kind='bar', title='Top Categories by Avg Rating', color='orange')
plt.xlabel('Category'); plt.ylabel('Avg Rating'); plt.show()

# 3. Free vs Paid App Distribution
df['Type'].value_counts().plot(kind='pie', autopct='%1.1f%%', title='Free vs Paid Apps', colors=['lightgreen', 'salmon'])
plt.ylabel(''); plt.show()

# 4. Reviews vs Ratings Scatter
sns.scatterplot(x='Reviews', y='Rating', data=df, alpha=0.5)
plt.title('Reviews vs Ratings'); plt.xlabel('Reviews'); plt.ylabel('Rating'); plt.show()

# 5. Most Expensive Apps
print(df[df['Type']=='Paid'].sort_values('Price', ascending=False).head(5)[['App','Price']])