# 📚 Book Web Scraper – CodeAlpha Internship

This beginner project scrapes book data from [Books to Scrape](http://books.toscrape.com/), a website designed for practicing web scraping.

---

## 🔍 What It Scrapes
- Book Title
- Price
- Availability
- Star Rating

---

## 💻 Tech Stack
- Python
- BeautifulSoup
- requests
- pandas

---

## ▶️ How to Run
1. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the script:
   ```bash
   python scraper.py
   ```
3. Output is saved as `books.csv`

---

## 📦 Output Sample

| Title                          | Price  | Availability | Rating |
|-------------------------------|--------|--------------|--------|
| A Light in the Attic          | £51.77 | In stock     | Three  |
| Tipping the Velvet            | £53.74 | In stock     | One    |
| Soumission                    | £50.10 | In stock     | One    |

---

## 📎 Source Site
http://books.toscrape.com/
