import requests
from bs4 import BeautifulSoup
import pandas as pd

# Target URL
url = "http://books.toscrape.com/"

# Get the page
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

# Find book data
books = soup.find_all("article", class_="product_pod")
data = []

for book in books:
    title = book.h3.a["title"]
    price = book.find("p", class_="price_color").text
    availability = book.find("p", class_="instock availability").text.strip()
    rating = book.p["class"][1]  # e.g., "Three"

    data.append([title, price, availability, rating])

# Create DataFrame
df = pd.DataFrame(data, columns=["Title", "Price", "Availability", "Rating"])
df.to_csv("books.csv", index=False)

print("✅ Data scraping completed. Saved to books.csv")
